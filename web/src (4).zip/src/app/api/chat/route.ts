import { NextResponse } from "next/server"
import Groq from "groq-sdk"
import { createClient } from "@supabase/supabase-js"

export const runtime = "nodejs"

function getGroqClient() {
  const apiKey = process.env.GROQ_API_KEY
  if (!apiKey) throw new Error("GROQ_API_KEY is missing")
  return new Groq({ apiKey })
}

function getSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !key) throw new Error("Supabase environment variables are missing")
  return createClient(url, key)
}

function extractJson(text: string) {
  const cleaned = text
    .trim()
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")

  const firstBrace = cleaned.indexOf("{")
  const lastBrace = cleaned.lastIndexOf("}")

  if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) {
    throw new Error("AI response does not contain valid JSON")
  }

  const jsonText = cleaned.slice(firstBrace, lastBrace + 1)
  try {
    return JSON.parse(jsonText)
  } catch {
    throw new Error("AI response JSON could not be parsed")
  }
}

export async function POST(req: Request) {
  try {
    const groq = getGroqClient()
    const supabase = getSupabase()

    const { message, currentPlan, sessionId } = await req.json()

    if (!message || !currentPlan) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 })
    }

    // Verify caller is authenticated
    const authHeader = req.headers.get("Authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
    const token = authHeader.replace("Bearer ", "")
    const { data: { user: authUser }, error: authError } = await supabase.auth.getUser(token)
    if (authError || !authUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const validSessionId = sessionId || null

    let history: Array<{ role: "user" | "assistant" | "system"; content: string }> =
      []
    let userId: string | null = null

    if (validSessionId) {
      const { data: session, error: sessionError } = await supabase
        .from("chat_sessions")
        .select("id, user_id")
        .eq("id", validSessionId)
        .maybeSingle()

      if (sessionError || !session) {
        return NextResponse.json(
          { error: "Chat session not found" },
          { status: 404 }
        )
      }

      userId = session.user_id

      const { data: historyData, error: historyError } = await supabase
        .from("chat_messages")
        .select("role, content")
        .eq("session_id", validSessionId)
        .order("created_at", { ascending: true })

      if (historyError) {
        console.warn("Chat history fetch warning:", historyError)
      }

      history = (historyData || []).map((msg: any) => ({
        role: msg.role as "user" | "assistant" | "system",
        content: msg.content as string,
      }))
    }

    const messages: Array<{
      role: "user" | "assistant" | "system"
      content: string
    }> = [
      {
        role: "system",
        content: `
You are a professional AI fitness coach.
You must modify the existing plan based on the user's request.
Return STRICT JSON ONLY, no markdown, no explanation, no extra text.
Use exactly this structure:
{
  "diet_plan": {
    "meals": [
      {
        "name": "Breakfast",
        "items": [
          { "food": "Eggs", "calories": 200, "protein": 20 }
        ],
        "total_calories": 300
      }
    ],
    "daily_total_calories": 1800
  },
  "workout_plan": [
    {
      "day": "Monday",
      "type": "Chest",
      "exercises": [
        { "name": "Bench Press", "sets": 3, "reps": 10 }
      ],
      "estimated_calories_burned": 350
    }
  ]
}
        `.trim(),
      },
      {
        role: "user",
        content: `CURRENT PLAN:\n${JSON.stringify(currentPlan)}`,
      },
      ...history,
      {
        role: "user",
        content: message,
      },
    ]

    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: messages as any,
      temperature: 0.5,
    })

    const raw = completion.choices[0]?.message?.content?.trim()

    if (!raw) {
      throw new Error("No response from AI")
    }

    const plan = extractJson(raw)

    // Note: plan persistence to workout_plans is handled by the client (dashboard)
    // to avoid double writes. We only persist the chat messages here.

    if (validSessionId) {
      const { error: saveChatError } = await supabase
        .from("chat_messages")
        .insert([
          {
            session_id: validSessionId,
            role: "user",
            content: message,
          },
          {
            session_id: validSessionId,
            role: "assistant",
            content: JSON.stringify(plan),
          },
        ])

      if (saveChatError) {
        console.warn("Chat save warning:", saveChatError)
      }
    }

    return NextResponse.json({ plan, sessionId: validSessionId })
  } catch (error: any) {
    console.error("CHAT ERROR:", error)
    return NextResponse.json(
      { error: error.message || "Failed to process chat" },
      { status: 500 }
    )
  }
}