export const colors = {
  bg: "#0A0A0F",
  card: "#111117",

  primary: "#7C3AED",
  secondary: "#06B6D4",

  energy: "#F97316",
  success: "#22C55E",

  text: "#FFFFFF",
  muted: "#A1A1AA",
}

export const gradients = {
  main: "linear-gradient(135deg, #7C3AED, #06B6D4)",
  energy: "linear-gradient(135deg, #F97316, #EF4444)",
  success: "linear-gradient(135deg, #22C55E, #4ADE80)",
}